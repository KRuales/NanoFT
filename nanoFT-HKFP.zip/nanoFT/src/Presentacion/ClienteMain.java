/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Presentacion;
import Dominio.*;
/**
 *HAMILTON EFRAIN PIPICANO ALVAREZ hpipicano@unicauca.edu.co
 * KAREN YULIETH RUALES PORTILLA kruales@unicauca.edu.co
 * FABER ANTONIO OSPINA CORTES fospina@unicauca.edu.co
 * PABLO ANDRES RAMIREZ DELGADOO panramirez@unicauca.edu.co
 * @author H7
 */
public class ClienteMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Contexto miContexto = new Contexto();
    
        absTarea tarea1 = new miTarea("tarea1","Hola");
        absTarea tarea2 = new miTarea("tarea2","Principios");
        absTarea tarea3 = new miTarea("tarea3","SOLID");
        absTarea tarea4 = new miTarea("tarea4","Bien");
        absTarea tarea5 = new miTarea("tarea5","Algo Fallo");
        
        absActividad repetitiva = new Repetitiva(5);
        absActividad concurrente = new Concurrente();
        absActividad condicional = new Condicional();
        absActividad secuencial = new Secuencial();
        
        repetitiva.agregarTarea(tarea1);
        concurrente.agregarTarea(tarea2);
        concurrente.agregarTarea(tarea3);
        condicional.agregarTarea(concurrente);
        condicional.agregarTarea(tarea4);
        condicional.agregarTarea(tarea5);
        secuencial.agregarTarea(repetitiva);
        secuencial.agregarTarea(condicional);
        
        
        secuencial.ejecutar(miContexto);
      
        
    }
    
}
