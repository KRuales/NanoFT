/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;

/**
 *HAMILTON EFRAIN PIPICANO ALVAREZ hpipicano@unicauca.edu.co
 * KAREN YULIETH RUALES PORTILLA kruales@unicauca.edu.co
 * FABER ANTONIO OSPINA CORTES fospina@unicauca.edu.co
 * PABLO ANDRES RAMIREZ DELGADOO panramirez@unicauca.edu.co
 * @author H7
 */
public class Repetitiva extends absActividad {
    
    private int numVeces;

    public Repetitiva(int numVeces) {
        this.numVeces = numVeces;
    }
    
    
    public Repetitiva(absTarea miTarea, int numVeces) {
        super();
        this.misTareas.add(miTarea);
        this.numVeces= numVeces;
    }

    /**
     * @return the numVeces
     */
    public int getNumVeces() {
        return numVeces;
    }

    /**
     * @param numVeces the numVeces to set
     */
    public void setNumVeces(int numVeces) {
        this.numVeces = numVeces;
    }

   
    @Override
    public void ejecutar(Contexto contexto) {
        for(int i = 0; i< numVeces; i++){
            getTareas().get(0).ejecutar(contexto);
        }
    }
    
}

