/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *HAMILTON EFRAIN PIPICANO ALVAREZ hpipicano@unicauca.edu.co
 * KAREN YULIETH RUALES PORTILLA kruales@unicauca.edu.co
 * FABER ANTONIO OSPINA CORTES fospina@unicauca.edu.co
 * PABLO ANDRES RAMIREZ DELGADOO panramirez@unicauca.edu.co
 * @author H7
 */
package Dominio;

/**
 *
 * @author H7
 */
public class Condicional extends absActividad {
    
    private boolean condicion;

    public Condicional() {
    }

    public void addPrevia(absTarea tarea) {
        getTareas().add(tarea);
    }

    public void addCondicion(boolean condicion) {
        this.condicion=condicion;
    }

    public void addSi(absTarea tarea) {
         getTareas().add(tarea);
    }

    public void addSino(absTarea tarea) {
         getTareas().add(tarea);
    }

    @Override
    public void ejecutar(Contexto contexto){
        getTareas().get(0).ejecutar(contexto);
        condicion = (contexto.isResultado());
        if(condicion){
            getTareas().get(1).ejecutar(contexto);
        } 
        else{
            getTareas().get(2).ejecutar(contexto);
        }
    }
    
    
    
}



