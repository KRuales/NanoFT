/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dominio;

/**
 *HAMILTON EFRAIN PIPICANO ALVAREZ hpipicano@unicauca.edu.co
 * KAREN YULIETH RUALES PORTILLA kruales@unicauca.edu.co
 * FABER ANTONIO OSPINA CORTES fospina@unicauca.edu.co
 * PABLO ANDRES RAMIREZ DELGADOO panramirez@unicauca.edu.co
 * @author H7
 */
public abstract class absTarea implements Runnable {

    private String nombre;
    private Contexto contexto;
   
    
 
    //Solamente para tareas o actividades paralelas
    @Override
    public void run() {
        this.ejecutar(getContexto());
    }
    
    public void ejecutar(Contexto contexto){}
    
    public absTarea(String nombre){
        this.nombre = nombre;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

   
    

    /**
     * @return the contexto
     */
    public Contexto getContexto() {
        return contexto;
    }

    /**
     * @param contexto the contexto to set
     */
    public void setContexto(Contexto contexto) {
        this.contexto = contexto;
    }
    

  
    
}
