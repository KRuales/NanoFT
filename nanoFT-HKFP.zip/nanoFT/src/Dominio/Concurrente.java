/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *HAMILTON EFRAIN PIPICANO ALVAREZ hpipicano@unicauca.edu.co
 * KAREN YULIETH RUALES PORTILLA kruales@unicauca.edu.co
 * FABER ANTONIO OSPINA CORTES fospina@unicauca.edu.co
 * PABLO ANDRES RAMIREZ DELGADOO panramirez@unicauca.edu.co
 * @author H7
 */
public class Concurrente extends absActividad {
    
   
    private  ArrayList<Thread> misHilos;

    public Concurrente() {
        super();
        misHilos = new ArrayList<>();
    }

    @Override
    public void ejecutar(Contexto contexto){
        for(absTarea cadaTarea:getTareas()){
            cadaTarea.setContexto(contexto);
            misHilos.add(new Thread(cadaTarea));
        }
        
        for(Thread cadaHilo:misHilos){
            cadaHilo.start();
        }
        
        for(Thread cadaHilo:misHilos){
            contexto.setResultado(true);
            try {
                cadaHilo.join();
            } catch (InterruptedException ex) {
                Logger.getLogger(Concurrente.class.getName()).log(Level.SEVERE, null, ex);
                contexto.setResultado(false);
            }
        }
        
        
    }
    
}
