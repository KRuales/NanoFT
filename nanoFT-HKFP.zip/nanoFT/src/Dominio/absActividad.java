/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dominio;

import java.util.ArrayList;

/**
 *HAMILTON EFRAIN PIPICANO ALVAREZ hpipicano@unicauca.edu.co
 * KAREN YULIETH RUALES PORTILLA kruales@unicauca.edu.co
 * FABER ANTONIO OSPINA CORTES fospina@unicauca.edu.co
 * PABLO ANDRES RAMIREZ DELGADOO panramirez@unicauca.edu.co
 * @author H7
 */
public abstract class  absActividad extends absTarea implements Runnable{
    
      ArrayList<absTarea> misTareas;

    public absActividad(){
        super("");
        misTareas = new ArrayList<>();
    }
    
    public void agregarTarea(absTarea tarea) {
        getTareas().add(tarea);
    }   

    /**
     * @return the Tareas
     */
    public ArrayList<absTarea> getTareas() {
        return misTareas;
    }

    /**
     * @param Tareas the Tareas to set
     */
    public void setTareas(ArrayList<absTarea> Tareas) {
        this.misTareas = Tareas;
    }

}
