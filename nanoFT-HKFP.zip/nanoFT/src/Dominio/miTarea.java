/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dominio;

/**
 *HAMILTON EFRAIN PIPICANO ALVAREZ hpipicano@unicauca.edu.co
 * KAREN YULIETH RUALES PORTILLA kruales@unicauca.edu.co
 * FABER ANTONIO OSPINA CORTES fospina@unicauca.edu.co
 * PABLO ANDRES RAMIREZ DELGADOO panramirez@unicauca.edu.co
 * @author H7
 */
public class miTarea extends absTarea {
       private String mensaje;
    
    public miTarea(String nombre, String mensaje) {
        super(nombre);
        this.mensaje = mensaje;
    }

    @Override
    public void ejecutar(Contexto contexto) {
        System.out.println(mensaje);
        // A ser programada por el programador
    }
}
